const express = require('express');
const router = express.Router();

const siteController = require('../app/controllers/SiteController');

router.post('/addTextFile',  siteController.addTextFile);
router.post('/upload',siteController.uploadFile);
router.post('/addFolder', siteController.addFolder);
router.get('/download/:id',  siteController.download);

module.exports = router;