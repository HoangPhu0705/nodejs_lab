const path = require("path");
const express = require('express');
const app = express();
const PORT = 3000;
const route = require("./routes");
const db = require('./config/db');
const errorHandler = require('./app/middlewares/errorHandler');
const cors = require('cors');
db.connect();

app.use(cors());
app.use(express.json());
app.use(
    express.urlencoded({
      extended: true,
    })
);
  



route(app);
app.use(errorHandler);
app.listen(PORT, () =>
  console.log(`Listening at http://localhost:${PORT}`)
);

