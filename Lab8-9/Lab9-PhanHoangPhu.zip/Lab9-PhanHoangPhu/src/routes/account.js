const express = require('express');
const router = express.Router();

const AccountController = require('../app/controllers/AccountController');


router.post('/account/register', AccountController.register);
router.post('/account/login', AccountController.login);

module.exports = router;