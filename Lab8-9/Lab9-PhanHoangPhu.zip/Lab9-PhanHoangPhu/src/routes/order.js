const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken')

const OrderController = require('../app/controllers/OrderController');
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (token == null) return res.sendStatus(401);

    jwt.verify(token, 'phanhoangphu', (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
}

router.get('/orders', authenticateToken,  OrderController.getAll);
router.post('/orders', authenticateToken, OrderController.create);
router.get('/orders/:id', authenticateToken, OrderController.getOne);
router.put('/orders/:id',authenticateToken, OrderController.update);
router.delete('/orders/:id',authenticateToken, OrderController.delete);


module.exports = router;