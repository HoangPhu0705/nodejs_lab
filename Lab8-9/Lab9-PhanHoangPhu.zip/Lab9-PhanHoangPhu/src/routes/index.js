const accountRouter = require('./account');
const productRouter = require('./product');
const orderRouter = require('./order');

function route(app) {
    app.use('/api',accountRouter);
    app.use('/api',productRouter);
    app.use('/api',orderRouter);

}


module.exports = route;