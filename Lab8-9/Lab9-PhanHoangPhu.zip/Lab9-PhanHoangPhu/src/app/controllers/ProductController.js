const Product = require("../models/Product");

class ProductController {
    async getAll(req, res) {
        try {
            const products = await Product.find();
            res.status(200).json(products);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    async create(req, res) {
        const { code, name, price, image, description } = req.body;

        try {
            const product = new Product({ code, name, price, image, description });
            await product.save();

            res.status(201).json({ message: "Product created successfully", product });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    async getOne(req, res) {
        try {
            const product = await Product.findById(req.params.id);
            if (!product) {
                return res.status(404).json({ message: "Product not found" });
            }
            res.status(200).json(product);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

x
    async update(req, res) {
        const { code, name, price, image, description } = req.body;

        try {
            const product = await Product.findById(req.params.id);
            if (!product) {
                return res.status(404).json({ message: 'Product not found' });
            }

            if (code) product.code = code;
            if (name) product.name = name;
            if (price) product.price = price;
            if (image) product.image = image;
            if (description) product.description = description;

            await product.save();
            res.status(200).json({ message: 'Product updated successfully', product });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }


    async delete(req, res){
        try{
            const product = await Product.findById(req.params.id);
            if(!product){
                return res.status(404).json({ message: 'Product not found' });
            }
            await product.deleteOne();
            res.status(200).json({message: 'Product removed successfully'});

        }catch(error){
            res.status(500).json({error: error.message})
        }
    }
}

module.exports = new ProductController();
