const mongoose = require("mongoose");

const OrderItemSchema = new mongoose.Schema({
  productCode: { type: String, required: true },
  quantity: { type: Number, required: true },
  price: { type: Number, required: true },
});

const OrderSchema = new mongoose.Schema({
  orderCode: { type: String, required: true, unique: true },
  total: { type: Number, required: true },
  items: [OrderItemSchema],
});

module.exports = mongoose.model("Order", OrderSchema);
