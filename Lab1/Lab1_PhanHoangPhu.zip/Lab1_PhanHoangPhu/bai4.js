function storeLocal(){
    var studentName = document.getElementById('studentName').value;
    var studentAge = document.getElementById('studentAge').value;
    var student = {
      name: studentName,
      age: studentAge
    };
    

    var students = JSON.parse(localStorage.getItem('students')) || [];

    students.push(student);

    localStorage.setItem("students", JSON.stringify(students));

    document.getElementById('studentForm').reset();

    for(var i = 0; i < students.length; i++){
        const markup = `<tr>
                            <th scope="col">${students[i].name}</th>
                            <th scope="col">${students[i].age}</th>
                        </tr`;
        document.querySelector(".local").insertAdjacentHTML('beforeend', markup);
    }
}



function storeSession() {
    var studentName = document.getElementById('studentName').value;
    var studentAge = document.getElementById('studentAge').value;
    var student = {
      name: studentName,
      age: studentAge
    };


    var students = JSON.parse(sessionStorage.getItem('students')) || []

    students.push(student);

    sessionStorage.setItem("students", JSON.stringify(students));

    document.getElementById('studentForm').reset();

    for(var i = 0; i < students.length; i++){
        const markup = `<tr>
                            <th scope="col">${students[i].name}</th>
                            <th scope="col">${students[i].age}</th>
                        </tr`;
        document.querySelector(".session").insertAdjacentHTML('beforeend', markup);
    }
}

window.onload = function() {
    var students = JSON.parse(sessionStorage.getItem('students')) || [];

    for (var i = 0; i < students.length; i++) {
        const markup = `<tr>
                            <th scope="col">${students[i].name}</th>
                            <th scope="col">${students[i].age}</th>
                        </tr>`;
        document.querySelector(".session").insertAdjacentHTML('beforeend', markup);
    }


    var students2 = JSON.parse(localStorage.getItem('students')) || [];
    for (var i = 0; i < students2.length; i++) {
        const markup = `<tr>
                            <th scope="col">${students2[i].name}</th>
                            <th scope="col">${students2[i].age}</th>
                        </tr>`;
        document.querySelector(".local").insertAdjacentHTML('beforeend', markup);
    }

};