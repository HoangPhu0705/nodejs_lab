function fetchAPI(){
    fetch('https://maivanmanh.github.io/503106/lab01/students.json')
    .then(res => {
        return res.json();
    })
    .then(data => {
        var students = data.data;
        for(var i = 0; i < students.length; i++){
            const markup = `<tr>
                                <th scope="col">${students[i].id}</th>
                                <th scope="col">${students[i].name}</th>
                                <th scope="col">${students[i].age}</th>
                            </tr`;
            document.querySelector("tbody").insertAdjacentHTML('beforeend', markup);
        }
    }).catch(err => console.error(err));
    ;
}


function fetchAjax(){
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'https://maivanmanh.github.io/503106/lab01/students.json', true);

    xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 400) {
            var data = JSON.parse(xhr.responseText);
            var students = data.data;
            for (var i = 0; i < students.length; i++) {
                const markup = `<tr>
                                <th scope="col">${students[i].id}</th>
                                <th scope="col">${students[i].name}</th>
                                <th scope="col">${students[i].age}</th>
                              </tr>`;
                document.querySelector("tbody").insertAdjacentHTML('beforeend', markup);
            }
        }else{
            console.error('Error:', xhr.status);
        }
    };
    xhr.onerror = function () {
        console.error('Request failed');
    };
    xhr.send();
}