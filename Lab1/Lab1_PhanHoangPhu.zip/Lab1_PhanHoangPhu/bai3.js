function downloadImage() {
  var imageUrl = document.getElementById("imageUrlInput").value;

  return new Promise(function(resolve, reject) {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", imageUrl, true);
    xhr.responseType = "blob";
  
    xhr.onload = () => {
      if (xhr.status === 200) {
        var blob = xhr.response;
        resolve(blob);
      }else{
        reject(new Error("Failed" + xhr.status));
      }
    };
  
    xhr.send();
  })

}

function displayImage(blob) {
  var imgElement = document.getElementById("imageDisplay");
  imgElement.src = URL.createObjectURL(blob);
}


//Promise then / catch
function loadImage() {
  downloadImage()
    .then(function(blob) {
      displayImage(blob);
    })
    .catch(function(error) {
      console.error(error);
    });
}


//async/await
async function loadImage2() {
  try {
    var blob = await downloadImage();
    displayImage(blob);
  } catch (error) {
    console.error(error);
  }
}
