function downloadImage() {
  var imageUrl = document.getElementById("imageUrlInput").value;

  var xhr = new XMLHttpRequest();
  xhr.open("GET", imageUrl, true);
  xhr.responseType = "blob";

  xhr.onload = () => {
    if (xhr.status === 200) {
      var blob = xhr.response;
      displayImage(blob);
    }
  };

  xhr.send();
}

function displayImage(blob) {
  var imgElement = document.getElementById("imageDisplay");
  imgElement.src = URL.createObjectURL(blob);
}


