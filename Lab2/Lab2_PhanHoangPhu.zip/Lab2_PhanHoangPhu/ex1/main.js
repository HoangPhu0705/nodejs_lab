const http = require('http');
const url = require('url');
const fs = require('fs');

http.createServer(function (req, res) {
    if (req.url === '/') {
        if (req.method === 'POST') {
            let body = '';
            req.on('data', (data) => {
                body += data.toString();
            });

            req.on('end', () => {
                    

                const n1 = Number(formData.get('number1'));
                const n2 = Number(formData.get('number2'));
                const operation = formData.get('operation');
                let result;

                if (operation === 'add') {
                    result = n1 + n2;
                } else if (operation === 'subtract') {
                    result = n1 - n2;
                } else if (operation === 'multiply') {
                    result = n1 * n2;
                } else if (operation === 'divide') {
                    result = n1 / n2;
                } else if (operation === 'none') {
                    res.statusCode = 400;
                    res.setHeader('Content-Type', 'text/html; charset=utf-8');
                    res.write("Bạn chưa chọn phép toán");
                    res.end();
                    return;
                }

                res.statusCode = 200;
                res.setHeader('Content-Type', 'text/html; charset=utf-8');
                res.write(`<h1>${n1} ${getOperatorSymbol(operation)} ${n2} = ${result}</h1>`);
                res.end();
            });
        } else {
            res.statusCode = 200;
            res.setHeader('Content-Type', 'text/html; charset=utf-8');
            var html = fs.readFileSync('./index.html');
            res.write(html);
            res.end();
        }
    }else{
        res.statusCode = 404;
        res.setHeader('Content-Type', 'text/html; charset=utf-8');
        res.write('Đường dẫn không hợp lệ');
        res.end();
    }
}).listen(3000);

function getOperatorSymbol(operation) {
    switch (operation) {
        case 'add':
            return '+';
        case 'subtract':
            return '-';
        case 'multiply':
            return '*';
        case 'divide':
            return '/';
        default:
            return '';
    }
}