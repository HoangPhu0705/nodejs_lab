const http = require('http');
const URL = require('url');
const port = 3000;
let students = [
  { id: 1, name: 'Hoang Phu', age: 20 },
  { id: 2, name: 'Minh Hieu', age: 18 },
  { id: 3, name: 'Duy Tan', age: 21 }
];


const server = http.createServer((req, res) => {
    const url = URL.parse(req.url, true);

    if (url.pathname === '/students' && req.method === 'GET') {         //[GET] /students             
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(students));
    }else if (url.pathname === '/students' && req.method === 'POST') {  //[POST] /students
        let body = '';
        req.on('data', (data) => {
          body += data;
        });
        req.on('end', () => {
          const newStudent = JSON.parse(body);
          students.push(newStudent);
          
          res.writeHead(201, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true }));
        });
    }else if(url.pathname.startsWith('/students/') && req.method === 'GET') {    //[GET] /students/:id
        const id = parseInt(url.pathname.split('/')[2]);
        const student = students.find((st) => st.id === id);
        if (student) {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(student));
          } else {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ message: 'Cannot find student' }));
        }
    }else if(url.pathname.startsWith('/students/') && req.method === 'PUT'){     //[PUT]  /students/:id  
        const id = parseInt(url.pathname.split('/')[2]);
        const stIndex = students.findIndex((st) => st.id === id);

        if(stIndex >= 0){
            let body = '';
            req.on('data', data => {
                body += data;
            });
            req.on('end', () => {
                const newStudent = JSON.parse(body);
                students[stIndex].name = newStudent.name;
                students[stIndex].age = newStudent.age;
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true }));
            });
        }else{
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ message: 'Cannot find student' }));
        }

    }else if(url.pathname.startsWith('/students/') && req.method === 'DELETE'){
        const id = parseInt(url.pathname.split('/')[2]);
        const stIndex = students.findIndex((st) => st.id === id);
        if(stIndex >= 0){
            let body = '';
            req.on('data', data => {
                body += data;
            });
            req.on('end', () => {
                students.splice(stIndex, 1);
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true }));
            });
        }else{
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ message: 'Cannot find student' }));
        }

    }else{
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: 'Invalid endpoint' }));
    }                  
});


server.listen(port, () => {
    console.log(`Server is listening on port http://localhost:${port}`);
});