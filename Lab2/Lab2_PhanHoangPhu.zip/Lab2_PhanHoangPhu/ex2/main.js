const http = require('http');
const url = require('url');
const fs = require('fs');

const accounts = [
    {
        email: "admin1@example.com",
        password: "admin123",
    },

    {
        email: "admin2@example.com",
        password: "admin234",
    }

]



http.createServer(function(req, res){
    const parsedUrl = url.parse(req.url, true);
    if(req.method == 'POST' && parsedUrl.pathname === '/login'){
        let body = '';
        req.on('data', function(data) {
            body += data.toString();
        });

        req.on('end', () => {
            const formData = new URLSearchParams(body);
            const email = formData.get('email');
            const password = formData.get('password');

            if(password == null) {
                res.statusCode = 404;
                res.setHeader('Content-Type', 'text/html, charset=utf-8');
                res.write("Mật khẩu không hợp lệ");
                res.end();
                return;
            }
            const account = accounts.find((acc) => acc.email === email && acc.password === password);

            if(account) {
                res.statusCode = 200;
                res.setHeader('Content-Type', 'text/html; charset=utf-8');
                res.write("Đăng nhập thành công");
                res.end();
                res.statusCode = 401;
                res.setHeader('Content-Type', 'text/html; charset=utf-8');
                res.write("Mật khẩu không hợp lệ");
                res.end(); 
            }
        });
    }else{
        if (parsedUrl.pathname == '/login') {
            res.statusCode = 404;
            res.setHeader('Content-Type', 'text/html; charset=utf-8');
            res.write("Phương thức GET không được hỗ trợ");
            res.end();
          } else {
            res.statusCode = 404;
            res.setHeader('Content-Type', 'text/html; charset=utf-8');
            res.write("Đường dẫn không hợp lệ");
            res.end();
        }
    }

}).listen(3000);