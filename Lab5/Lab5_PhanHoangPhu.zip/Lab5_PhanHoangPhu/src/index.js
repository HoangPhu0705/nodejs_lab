const express = require("express");
const app = express();
const path = require("path");
const handlebars = require("express-handlebars");
const cors = require("cors");
const fetch = (...args) => import("node-fetch").then(({ default: fetch }) => fetch(...args));
const myBodyParser = require("./middlewares/body-parser-custom.js");
const rateLimit = require("express-rate-limit");
const { check, validationResult } = require('express-validator');
const session = require('express-session');
const flash = require('connect-flash');




require("dotenv").config();
const PORT = process.env.PORT;
const URL = process.env.URL;
const TOKEN = process.env.TOKEN;

app.use(express.static(path.join(__dirname, "public")));
app.use(cors());
const limiter = rateLimit({
    windowMs: 60 * 60 * 1000,
    max: 100, 
});

app.use(limiter);
  
app.use(session({
    secret: 'phanphu',
    resave: false,
    saveUninitialized: true
}));
app.use(flash());


app.engine(
    "hbs",
    handlebars.engine({
        extname: ".hbs",
        defaultLayout: false,
    })
);

// [fetch User]
async function fetchUsers() {
    try {
        let users = [];
        const response = await fetch(URL);
        const data = await response.json();
        users = users.concat(data);
        return users;
    } catch (err) {
        console.error(err);
    }
}





//[Add user --POST]
app.post("/public-api/users",     
    myBodyParser,
    [
        check('gender').custom((value) => ['male', 'female'].includes(value.toLowerCase())).withMessage('Gender must be either male or female')
    ],
    async (req, res) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            req.flash('error', errors.array());
            return res.status(400).json({ errors: errors.array() });
        }
        const userData = req.body;
        const response = await fetch(URL, {
            method: "POST",
            body: JSON.stringify(userData),
            headers: {
                "Content-Type": "application/json",
            },
        });
        const data = await response.json();

        if (response.ok) {
            req.flash('success', 'User added successfully');
            res.redirect('back');
        } else {
            res.status(response.status).send(data);
        }
});


//[GET all user]
app.get("/public-api/users", async (req, res) => {
    const users = await fetchUsers();
    const errorFlash = req.flash('error');
    const successFlash = req.flash('success');

    res.render("index", { users, errorFlash, successFlash });
});



app.get("/public-api/users/:id", async (req, res) => {
    const userid = req.url.split("/users/")[1];
    const response = await fetch(
        `${URL}/${userid}`
    );
    const user = await response.json();
    
    res.render("profile", {user});
});



app.delete("/public-api/users/:id", async (req, res) => {
    const userid = req.url.split("/users/")[1];
    const response = await fetch(
        `${URL}/${userid} `,
        {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + TOKEN,
            },
        }
    );
    if (response.ok) {
        res.redirect('back');
    } else {
        const data = await response.json();
        console.log(data);
    }
});




app.put("/public-api/users/:id",    
    [
        check('gender').custom((value) => ['male', 'female'].includes(value.toLowerCase())).withMessage('Gender must be either male or female')
    ], async (req, res) =>{
    const userid = req.url.split("/users/")[1];
    const userdata = req.body;
    const response = await fetch(`${URL}/${userid}`, {
        method: "PUT",
        body: JSON.stringify(userdata),
        headers: {
            "Content-Type": "application/json",
        },
    });


    const data = await response.json();
    if (response.ok) {
        res.status(201).send(data);
    } else {
        res.status(response.status).send(data);
    }
});


app.set("view engine", "hbs");
app.set("views", path.join(__dirname, "resources/views"));
app.listen(PORT, () => console.log(`http://localhost:${PORT}`));


