const querystring = require('querystring');

function bodyParserMiddleware(req, res, next) {
  let data = "";
  req.on("data", (chunk) => {
    data += chunk;
  });
  req.on("end", () => {
    req.body = querystring.parse(data);
    next();
  });
}

module.exports = bodyParserMiddleware;