const express = require('express');
const router = express.Router();
const siteController = require('../app/controllers/SiteController');
const ensureAuthenticated = require('../services/auth');
const multer = require('multer');
const upload = multer({ dest: 'src/public/img' })


router.get('/', ensureAuthenticated, siteController.index);
router.get('/login', siteController.login);
router.get('/add', siteController.getAddProduct);
router.post('/add', upload.single('image'), siteController.addProduct);
router.post('/edit/:stt', upload.single('image'), siteController.editProduct)
router.get('/edit/:stt', siteController.getEditProduct)
router.get('/delete/:stt', siteController.deleteProduct);
router.get('/:stt', siteController.product_detail);
router.post('/login', siteController.handleLogin);


module.exports = router;