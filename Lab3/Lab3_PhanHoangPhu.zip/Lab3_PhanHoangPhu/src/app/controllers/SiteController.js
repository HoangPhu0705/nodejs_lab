require('dotenv').config();

let products = [
    { stt: 1, name: 'Iphone XS', price: 1199, description : 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', image : 'image1.jpg'},
    { stt: 2, name: 'Iphone 12 Pro', price:1399, description : 'Lorem ipsum dolor sit amet, consect.' , image : 'images2.jpg'},
    { stt: 3, name: 'Air Pod Pro', price: 499, description: 'Lorem ipsum dolor sit amet, consect.', image: 'image3.jpg'},
];

const users = [
    { email: process.env.ADMIN_EMAIL, password: process.env.ADMIN_PASSWORD }
];


class SiteController{
    index(req, res){
        res.render('index', {products: products});
    }

    login(req, res){
       
        res.render('login');
    }

    product_detail(req, res){
        const stt = req.url.split('/')[1];
        const product = products.find(product => product.stt === parseInt(stt));

        if (product) {
            res.render('product-details', { product: product });
        } else {
            res.send('Product not found');
        }
    }

    handleLogin(req, res) {
        
        const { email, password } = req.body;
        const user = users.find(user => user.email === email && user.password === password);

        if (user) {
            req.session.user = user;
            res.redirect('/');
        } else {
            res.redirect('/login');
        }
    }

    getAddProduct(req, res) {
        res.render('addProduct');
    }



    addProduct(req, res){
        const { name, price, description} = req.body;
        const maxStt = Math.max(...products.map(product => product.stt));
        const newProduct = {
            stt: maxStt + 1,
            name: name,
            price: parseFloat(price),
            description: description,
            image: req.file.filename
        };

        products.push(newProduct);
        res.redirect('/');
    }

    getEditProduct(req, res){
        const stt = req.url.split('/edit/')[1];
        const product = products.find(product => product.stt === parseInt(stt));
        
        if (product) {
            res.render('editProduct', { product: product });
        } else {
            res.send('Product not found');
        }
    }

    editProduct(req, res){
        const stt = req.url.split('/edit/')[1];

        const { name, price, description} = req.body;
        const product = products.find(product => product.stt === parseInt(stt));
        
        if (product) {
            product.name = name;
            product.price = parseFloat(price);
            product.description = description;
            product.image = req.file.filename;
            res.redirect('/');
        } else {
            res.send('Product not found');
        }

    
    }

    deleteProduct(req, res){
        const stt = parseInt(req.url.split('/delete/')[1]);
        const product = products.find(product => product.stt === stt);
            
        if (product) {
            products = products.filter(product => product.stt !== stt);
            res.redirect('/');
        } else {
            res.send('Product not found');
        }
    }



}

module.exports = new SiteController();