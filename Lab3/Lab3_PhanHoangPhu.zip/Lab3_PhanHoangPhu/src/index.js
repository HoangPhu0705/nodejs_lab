const express = require('express');
const handlebars = require('express-handlebars');
const path = require('path');
const app = express();
const port = 3000;
const session = require('express-session');
const passport = require('passport');
const route = require('./routes');


app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());
app.use(
    express.urlencoded({
      extended: true,
    })  
);

app.engine('hbs', handlebars.engine({
    extname: 'hbs',
    defaultLayout: false,
    })
);

app.set('view engine', 'hbs');
app.set("views", path.join(__dirname, 'resources/views'));


app.use(session({
    secret: 'secret',
    resave: false,
    saveUninitialized: false,
}));


app.use(passport.initialize());
app.use(passport.session());

passport.serializeUser(function(user, done) {
    done(null, user);
});

passport.deserializeUser(function(user, done) {
    done(null, user);
});




route(app);



app.listen(port, () => console.log(`http://localhost:${port}`));


